package com.company;
import java.util.*;

class Main {
    public static void main(String[] argv) throws Exception {
        try {
            boolean True = true;
            Random random = new Random();
            Stack<Integer> stack = new Stack<Integer>();
            Scanner sc = new Scanner(System.in);


            stack.add(1);
            stack.add(2);
            stack.add(3);
            stack.add(4);

            System.out.println("Stack-ul dumneavoasta este: "
                    + stack +". \nAlegeti o litera: ");
            System.out.println("A-Adaugare\n" +
                    "B-Extragere\n" +
                    "S-Stop\n");

            while (True) {
                System.out.print("In ce meniu doriti sa intrati (A,B sau C) ?");
                String c = sc.nextLine();
                String d = c.toLowerCase();
                switch (d) {
                    case "a":
                        int rand__size = random.nextInt(stack.size());
                        int rand_num = random.nextInt(100);
                        System.out.println("Stiva dvs. este: " + stack);

                        stack.add(rand__size, rand_num);

                        System.out.println("Noua stiva a dvs. este: " + stack);
                        break;
                    case "b":
                        int rand_size = random.nextInt(stack.size());
                        ListIterator<Integer> iterator = stack.listIterator(rand_size);

                        System.out.println("\nElementul cu indexul:  " + rand_size );

                        System.out.print(" are valoarea : "
                                + iterator.next());
                        break;
                    case "s":
                        System.exit(0);
                    default:
                        System.out.println("Reintroduceti o litera valida! \n");
                        break;


                }
            }
        } catch (IndexOutOfBoundsException e) {
            System.out.println("Exceptia este: " + e);
        }
    }
}
