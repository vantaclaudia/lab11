package com.company;

import java.util.*;

class Main
{
    public static void main(String[] args)
    {
        Scanner scan = new Scanner(System.in);
        Stack<Integer> operation  = new Stack<Integer>();
        Stack<Double> value = new Stack<Double>();
        Stack<Integer> operationtmp  = new Stack<Integer>();
        Stack<Double> valuetmp = new Stack<Double>();
        System.out.println("Introduceti expresia dorita: \n");
        String input = scan.next();
        input = "0" + input;
        input = input.replaceAll("-","+-");
        String temp = "";
        for (int i = 0;i < input.length();i++)
        {
            char ch = input.charAt(i);
            if (ch == '-')
                temp = "-" + temp;
            else if (ch != '+' &&  ch != '*' && ch != '/')
                temp = temp + ch;
            else
            {
                value.push(Double.parseDouble(temp));
                operation.push((int)ch);
                temp = "";
            }
        }
        value.push(Double.parseDouble(temp));
        char operators[] = {'/','*','+'};
        for (int i = 0; i < 3; i++)
        {
            boolean it = false;
            while (!operation.isEmpty())
            {
                int operator = operation.pop();
                double v1 = value.pop();
                double v2 = value.pop();
                if (operator == operators[i])
                {
                    if (i == 0)
                    {
                        valuetmp.push(v2 / v1);
                        it = true;
                        break;
                    }
                    else if (i == 1)
                    {
                        valuetmp.push(v2 * v1);
                        it = true;
                        break;
                    }
                    else if (i == 2)
                    {
                        valuetmp.push(v2 + v1);
                        it = true;
                        break;
                    }
                }
                else
                {
                    valuetmp.push(v1);
                    value.push(v2);
                    operationtmp.push(operator);
                }
            }
            while (!valuetmp.isEmpty())
                value.push(valuetmp.pop());
            while (!operationtmp.isEmpty())
                operation.push(operationtmp.pop());
            if (it)
                i--;
        }
        System.out.println("\nRezultatul este: "+value.pop());
    }
}
