package com.company;

import java.util.Stack;

class Main {

    static void Push(Stack st, int a) {
        st.push(a);
        System.out.println("PUSH(" + a + ")");
        System.out.println("Stack: " + st);
    }

    static void Pop(Stack st) {
        System.out.print("POP() : ");
        Integer a = (Integer) st.pop();
        System.out.println(a);
        System.out.println("Stack: " + st);
    }

    public static void main(String args[]) {
        Stack st = new Stack();
        System.out.println("stack: " + st);
        Push(st, 23);
        Push(st, 55);
        Push(st, 89);
        Pop(st);

    }
}