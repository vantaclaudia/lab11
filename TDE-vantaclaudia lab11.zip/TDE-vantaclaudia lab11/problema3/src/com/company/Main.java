package com.company;

class Main
{
    int size;
    int type1, type2;
    int array[];

    // Constructor
    Main(int n)
    {
        array = new int[n];
        size = n;
        type1 = -1;
        type2 = size;
    }

    void push1(int x)
    {
        if (type1 < type2 - 1)
        {
            type1++;
            array[type1] = x;
        }
        else
        {
            System.out.println("Surplus");
            System.exit(1);
        }
    }

    void push2(int x)
    {
        if (type1 < type2 -1)
        {
            type2--;
            array[type2] = x;
        }
        else
        {
            System.out.println("Surplus");
            System.exit(1);
        }
    }

    int pop1()
    {
        if (type1 >= 0)
        {
            int x = array[type1];
            type1--;
            return x;
        }
        else
        {
            System.out.println("Lipsa");
            System.exit(1);
        }
        return 0;
    }

    int pop2()
    {
        if(type2 < size)
        {
            int x =array[type2];
            type2++;
            return x;
        }
        else
        {
            System.out.println("Lipsa");
            System.exit(1);

        }
        return 0;
    }

    public static void main(String args[])
    {
        Main ts = new Main(5);
        ts.push1(3);
        ts.push2(45);
        ts.push2(21);
        ts.push1(32);
        ts.push2(2);

        System.out.println("Ultimul element din prima stiva este: " + ts.pop1());
        System.out.println("Ultimul element din a doua stiva este: " + ts.pop2());
    }
}